package com.example.submission_flutter_pemula_dicoding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
